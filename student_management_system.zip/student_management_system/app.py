import sqlite3

DB_NAME = "students.db"

def connect_db():
    return sqlite3.connect(DB_NAME)

def setup_database():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                course TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                marks REAL NOT NULL
            )
        """)

def add_student():
    name = input("Student name: ").strip()
    course = input("Course: ").strip()
    email = input("Email: ").strip()
    try:
        marks = float(input("Marks (%): "))
        with connect_db() as conn:
            conn.execute(
                "INSERT INTO students (name, course, email, marks) VALUES (?, ?, ?, ?)",
                (name, course, email, marks)
            )
        print("Student added successfully.\n")
    except ValueError:
        print("Please enter valid marks.\n")
    except sqlite3.IntegrityError:
        print("Email already exists.\n")

def view_students():
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT id, name, course, email, marks FROM students ORDER BY id"
        ).fetchall()

    if not rows:
        print("No students found.\n")
        return

    print("\nID | Name | Course | Email | Marks")
    print("-" * 65)
    for row in rows:
        print(f"{row[0]} | {row[1]} | {row[2]} | {row[3]} | {row[4]}%")
    print()

def search_student():
    keyword = input("Enter name or course to search: ").strip()
    with connect_db() as conn:
        rows = conn.execute(
            """SELECT id, name, course, email, marks
               FROM students
               WHERE name LIKE ? OR course LIKE ?""",
            (f"%{keyword}%", f"%{keyword}%")
        ).fetchall()

    if not rows:
        print("No matching student found.\n")
        return

    for row in rows:
        print(f"ID: {row[0]}, Name: {row[1]}, Course: {row[2]}, "
              f"Email: {row[3]}, Marks: {row[4]}%")
    print()

def delete_student():
    try:
        student_id = int(input("Enter student ID to delete: "))
        with connect_db() as conn:
            cursor = conn.execute("DELETE FROM students WHERE id = ?", (student_id,))
        print("Student deleted.\n" if cursor.rowcount else "Student ID not found.\n")
    except ValueError:
        print("Please enter a valid ID.\n")

def main():
    setup_database()

    while True:
        print("===== Student Management System =====")
        print("1. Add Student")
        print("2. View Students")
        print("3. Search Student")
        print("4. Delete Student")
        print("5. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            add_student()
        elif choice == "2":
            view_students()
        elif choice == "3":
            search_student()
        elif choice == "4":
            delete_student()
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.\n")

if __name__ == "__main__":
    main()
