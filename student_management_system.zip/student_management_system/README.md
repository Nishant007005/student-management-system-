# Student Management System

A simple Python project for managing student records using SQLite.

## Features
- Add student records
- View all students
- Search by name or course
- Delete student records
- Persistent SQLite database

## Technologies
- Python
- SQLite
- SQL

## How to Run

1. Install Python 3.
2. Open a terminal in this folder.
3. Run:

```bash
python app.py
```

The `students.db` database is created automatically when the program starts.
